import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CurrencySelect } from "@/components/ui/currency-select";
import { CountrySelect } from "@/components/ui/country-select";
import { insertReceiptSchema, type InsertReceipt, type ReceiptItem, type PaymentMethod } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { TAX_TYPES, PAYMENT_METHODS, calculateTax, calculateItemTotal, getCurrencySymbol, formatCurrency } from "@/lib/currency";
import { Globe, Hash, Building, User, ShoppingCart, Calculator, CreditCard, Plus, Trash2 } from "lucide-react";
import { z } from "zod";

const formSchema = insertReceiptSchema.extend({
  receiptPrefix: z.string().min(1, "Prefix is required"),
  nextNumber: z.number().min(1, "Number must be positive"),
});

type FormData = z.infer<typeof formSchema>;

interface ReceiptFormProps {
  onReceiptCreated: (receipt: any) => void;
}

export function ReceiptForm({ onReceiptCreated }: ReceiptFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [items, setItems] = useState<ReceiptItem[]>([
    { id: "1", name: "", quantity: 1, unitPrice: 0, total: 0 }
  ]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    { id: "1", method: "cash", amount: 0 }
  ]);

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const { data: nextNumberData } = useQuery({
    queryKey: ["/api/receipts/next-number"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      receiptNumber: "",
      businessName: "",
      businessPhone: "",
      businessEmail: "",
      businessAddress: "",
      businessTaxId: "",
      businessRegNumber: "",
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      customerAddress: "",
      currency: "USD",
      country: "US",
      subtotal: "0",
      taxType: "none",
      taxRate: "0",
      taxAmount: "0",
      taxInclusive: false,
      totalAmount: "0",
      paymentMethods: [{ id: "1", method: "cash", amount: 0 }],
      paymentStatus: "paid",
      paymentDate: new Date(),
      paymentNotes: "",
      items: [],
      receiptPrefix: "REC",
      nextNumber: 1,
    },
  });

  // Update form with settings data
  useEffect(() => {
    if (settings) {
      form.setValue("businessName", settings.businessName || "");
      form.setValue("businessPhone", settings.businessPhone || "");
      form.setValue("businessEmail", settings.businessEmail || "");
      form.setValue("businessAddress", settings.businessAddress || "");
      form.setValue("businessTaxId", settings.businessTaxId || "");
      form.setValue("businessRegNumber", settings.businessRegNumber || "");
      form.setValue("currency", settings.defaultCurrency || "USD");
      form.setValue("country", settings.defaultCountry || "US");
      form.setValue("taxType", settings.defaultTaxType || "none");
      form.setValue("taxRate", settings.defaultTaxRate || "0");
      form.setValue("receiptPrefix", settings.receiptPrefix || "REC");
      form.setValue("nextNumber", settings.nextNumber || 1);
    }
  }, [settings, form]);

  // Update receipt number when next number data changes
  useEffect(() => {
    if (nextNumberData?.receiptNumber) {
      form.setValue("receiptNumber", nextNumberData.receiptNumber);
    }
  }, [nextNumberData, form]);

  const createReceiptMutation = useMutation({
    mutationFn: async (data: InsertReceipt) => {
      const response = await apiRequest("POST", "/api/receipts", data);
      return response.json();
    },
    onSuccess: (receipt) => {
      toast({ title: "Receipt created successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/receipts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/receipts/next-number"] });
      onReceiptCreated(receipt);
      // Reset form
      setItems([{ id: "1", name: "", quantity: 1, unitPrice: 0, total: 0 }]);
      setPaymentMethods([{ id: "1", method: "cash", amount: 0 }]);
      form.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error creating receipt", 
        description: error.message || "An error occurred",
        variant: "destructive"
      });
    },
  });

  const addItem = () => {
    const newItem: ReceiptItem = {
      id: Date.now().toString(),
      name: "",
      quantity: 1,
      unitPrice: 0,
      total: 0,
    };
    setItems([...items, newItem]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    }
  };

  const updateItem = (id: string, field: keyof ReceiptItem, value: any) => {
    setItems(items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          updatedItem.total = calculateItemTotal(updatedItem.quantity, updatedItem.unitPrice);
        }
        return updatedItem;
      }
      return item;
    }));
  };

  const addPaymentMethod = () => {
    const newPayment: PaymentMethod = {
      id: Date.now().toString(),
      method: "cash",
      amount: 0,
    };
    setPaymentMethods([...paymentMethods, newPayment]);
  };

  const removePaymentMethod = (id: string) => {
    if (paymentMethods.length > 1) {
      setPaymentMethods(paymentMethods.filter(pm => pm.id !== id));
    }
  };

  const updatePaymentMethod = (id: string, field: keyof PaymentMethod, value: any) => {
    setPaymentMethods(paymentMethods.map(pm => {
      if (pm.id === id) {
        return { ...pm, [field]: value };
      }
      return pm;
    }));
  };

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const taxRate = parseFloat(form.watch("taxRate") || "0");
  const taxInclusive = form.watch("taxInclusive");
  const taxAmount = form.watch("taxType") !== "none" ? calculateTax(subtotal, taxRate, taxInclusive) : 0;
  const totalAmount = taxInclusive ? subtotal : subtotal + taxAmount;

  // Update form values when calculations change
  useEffect(() => {
    form.setValue("subtotal", subtotal.toFixed(2));
    form.setValue("taxAmount", taxAmount.toFixed(2));
    form.setValue("totalAmount", totalAmount.toFixed(2));
    form.setValue("items", items);
  }, [subtotal, taxAmount, totalAmount, items, form]);

  // Sync payment methods with form and auto-adjust amounts
  useEffect(() => {
    // If there's only one payment method and amount is 0, auto-fill with total amount
    if (paymentMethods.length === 1 && paymentMethods[0].amount === 0 && totalAmount > 0) {
      const updated = [{ ...paymentMethods[0], amount: totalAmount }];
      setPaymentMethods(updated);
    }
  }, [paymentMethods.length, totalAmount]);

  // Sync payment methods with form
  useEffect(() => {
    form.setValue("paymentMethods", paymentMethods);
  }, [paymentMethods]);

  const onSubmit = (data: FormData) => {
    // Ensure items and paymentMethods are current
    const { receiptPrefix, nextNumber, ...receiptData } = data;
    
    // Override with current state to ensure we have the latest values
    const finalData = {
      ...receiptData,
      items,
      paymentMethods,
    };
    
    createReceiptMutation.mutate(finalData as any);
  };

  const currency = form.watch("currency");
  const currencySymbol = getCurrencySymbol(currency);

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          
          {/* Regional Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                Regional Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <FormControl>
                      <CurrencySelect
                        value={field.value}
                        onValueChange={field.onChange}
                        placeholder="Select currency"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country/Region</FormLabel>
                    <FormControl>
                      <CountrySelect
                        value={field.value}
                        onValueChange={field.onChange}
                        placeholder="Select country"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Receipt Numbering */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hash className="h-5 w-5 text-primary" />
                Receipt Numbering
              </CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="receiptPrefix"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prefix</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="REC" data-testid="input-receipt-prefix" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="nextNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Next Number</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-next-number"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <Label>Preview</Label>
                <div className="px-3 py-2 bg-muted rounded-md text-muted-foreground font-mono">
                  {form.watch("receiptPrefix")}-{form.watch("nextNumber")?.toString().padStart(3, "0")}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Business Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5 text-primary" />
                Business Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Name *</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter business name" data-testid="input-business-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="businessPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter phone number" data-testid="input-business-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="businessEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" placeholder="business@example.com" data-testid="input-business-email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="businessAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Enter business address" rows={3} data-testid="textarea-business-address" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="businessTaxId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tax ID/VAT Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter tax identification" data-testid="input-business-tax-id" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="businessRegNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Registration Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter registration number" data-testid="input-business-reg-number" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Customer Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Customer Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter customer name" data-testid="input-customer-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Phone</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter customer phone" data-testid="input-customer-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="customerEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="customer@example.com" data-testid="input-customer-email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer Address</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Enter customer address" rows={3} data-testid="textarea-customer-address" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Items */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5 text-primary" />
                  Items
                </CardTitle>
                <Button type="button" onClick={addItem} data-testid="button-add-item">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {items.map((item, index) => (
                <div key={item.id} className="grid grid-cols-12 gap-3 items-end pb-3 border-b">
                  <div className="col-span-4">
                    <Label>Item Name</Label>
                    <Input
                      value={item.name}
                      onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                      placeholder="Item description"
                      data-testid={`input-item-name-${index}`}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                      min="1"
                      data-testid={`input-item-quantity-${index}`}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Unit Price</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-muted-foreground">{currencySymbol}</span>
                      <Input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) => updateItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                        step="0.01"
                        className="pl-8"
                        data-testid={`input-item-price-${index}`}
                      />
                    </div>
                  </div>
                  <div className="col-span-2">
                    <Label>Total</Label>
                    <div className="px-3 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-md font-mono font-bold text-blue-900">
                      {formatCurrency(item.total, currency)}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <Button
                      type="button"
                      variant="destructive"
                      onClick={() => removeItem(item.id)}
                      disabled={items.length === 1}
                      className="w-full"
                      data-testid={`button-remove-item-${index}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Tax Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" />
                Tax Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="taxType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tax Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-tax-type">
                            <SelectValue placeholder="Select tax type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {TAX_TYPES.map((tax) => (
                            <SelectItem key={tax.value} value={tax.value}>
                              {tax.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="taxRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tax Rate (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field}
                          step="0.01"
                          min="0"
                          max="100"
                          data-testid="input-tax-rate"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="taxInclusive"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="checkbox-tax-inclusive"
                      />
                    </FormControl>
                    <FormLabel className="text-sm">Tax inclusive pricing</FormLabel>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Payment Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Payment Methods
              </CardTitle>
              <p className="text-sm text-gray-500 mt-1">
                Add multiple payment methods for split payments
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {paymentMethods.map((payment, index) => (
                  <div key={payment.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">
                        Payment {index + 1}
                      </span>
                      {paymentMethods.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removePaymentMethod(payment.id)}
                          data-testid={`button-remove-payment-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Method</Label>
                        <Select
                          value={payment.method}
                          onValueChange={(value) => updatePaymentMethod(payment.id, "method", value)}
                        >
                          <SelectTrigger data-testid={`select-payment-method-${index}`}>
                            <SelectValue placeholder="Select method" />
                          </SelectTrigger>
                          <SelectContent>
                            {PAYMENT_METHODS.map((method) => (
                              <SelectItem key={method.value} value={method.value}>
                                <span className="flex items-center gap-2">
                                  <span>{method.icon}</span>
                                  <span>{method.label}</span>
                                </span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Amount</Label>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          value={payment.amount}
                          onChange={(e) => updatePaymentMethod(payment.id, "amount", parseFloat(e.target.value) || 0)}
                          data-testid={`input-payment-amount-${index}`}
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button
                type="button"
                variant="outline"
                onClick={addPaymentMethod}
                className="w-full"
                data-testid="button-add-payment-method"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Payment Method
              </Button>
              
              {/* Payment total validation */}
              {(() => {
                const paymentTotal = paymentMethods.reduce((sum, pm) => sum + pm.amount, 0);
                const diff = Math.abs(paymentTotal - totalAmount);
                if (diff > 0.01) {
                  return (
                    <div className="text-sm text-amber-600 bg-amber-50 p-3 rounded-md">
                      Payment methods total ({formatCurrency(paymentTotal, currency)}) should equal receipt total ({formatCurrency(totalAmount, currency)})
                    </div>
                  );
                }
                return null;
              })()}
              
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="paymentStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-payment-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="paid">Paid</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="overdue">Overdue</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="paymentDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment Date</FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          value={field.value && !isNaN(new Date(field.value).getTime()) ? new Date(field.value).toISOString().split('T')[0] : ''}
                          onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : new Date())}
                          data-testid="input-payment-date"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="paymentNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Additional payment information" 
                        rows={2}
                        data-testid="textarea-payment-notes"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Summary */}
          <Card className="bg-gradient-to-br from-slate-50 to-gray-100">
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center text-base">
                  <span className="text-gray-700">Subtotal:</span>
                  <span className="font-mono font-semibold text-lg bg-white px-3 py-1.5 rounded-md border border-gray-200" data-testid="text-subtotal">
                    {formatCurrency(subtotal, currency)}
                  </span>
                </div>
                {form.watch("taxType") !== "none" && (
                  <div className="flex justify-between items-center text-base">
                    <span className="text-gray-700">Tax ({taxRate}%):</span>
                    <span className="font-mono font-semibold text-lg bg-white px-3 py-1.5 rounded-md border border-gray-200" data-testid="text-tax">
                      {formatCurrency(taxAmount, currency)}
                    </span>
                  </div>
                )}
                <div className="border-t-2 border-gray-300 pt-3 mt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-gray-900">Total Amount:</span>
                    <span className="font-mono text-2xl font-bold text-primary bg-white px-4 py-2 rounded-lg border-2 border-primary shadow-md" data-testid="text-total">
                      {formatCurrency(totalAmount, currency)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 pt-4">
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={createReceiptMutation.isPending}
                  data-testid="button-generate-receipt"
                >
                  {createReceiptMutation.isPending ? "Generating..." : "Generate Receipt"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </Form>
    </div>
  );
}
