import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card } from "@/components/ui/card";

export default function FAQPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4" data-testid="faq-title">
          Frequently Asked Questions
        </h1>
        <p className="text-xl text-gray-600">
          Everything you need to know about generating professional receipts
        </p>
      </div>

      <Card className="p-6 mb-8">
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger className="text-left">
              What is a receipt and why is it important?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                A receipt is a written acknowledgment that a payment has been received for goods or services. Receipts are 
                crucial for both businesses and customers as they serve as proof of purchase, help track expenses for tax 
                purposes, facilitate returns and exchanges, and provide documentation for warranty claims. For businesses, 
                receipts are essential for accounting, inventory management, and tax compliance. They create a paper trail 
                that can protect both parties in case of disputes.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-2">
            <AccordionTrigger className="text-left">
              What's the difference between a receipt and an invoice?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed mb-3">
                While both are important business documents, receipts and invoices serve different purposes:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li><strong>Invoice:</strong> A request for payment sent before or at the time goods/services are provided. 
                It includes payment terms and due dates.</li>
                <li><strong>Receipt:</strong> Proof that payment has been received. It's issued after payment is made and 
                confirms the transaction is complete.</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-3">
                In simple terms: an invoice asks for money, while a receipt confirms money has been received.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-3">
            <AccordionTrigger className="text-left">
              What information should be included on a receipt?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed mb-3">
                A professional receipt should include the following information:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Business name, address, and contact information</li>
                <li>Receipt number (for tracking and record-keeping)</li>
                <li>Date and time of transaction</li>
                <li>Itemized list of products or services purchased</li>
                <li>Individual prices and quantities</li>
                <li>Subtotal, tax amount, and total amount paid</li>
                <li>Payment method (cash, card, check, etc.)</li>
                <li>Tax identification number (if applicable)</li>
                <li>Business registration number (in some jurisdictions)</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-4">
            <AccordionTrigger className="text-left">
              How long should I keep receipts?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed mb-3">
                The retention period for receipts varies by country and purpose:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li><strong>Business expenses (USA):</strong> IRS recommends keeping receipts for at least 3-7 years</li>
                <li><strong>Business expenses (UK):</strong> HMRC requires 6 years for most businesses</li>
                <li><strong>Business expenses (Canada):</strong> CRA requires 6 years from the end of the tax year</li>
                <li><strong>Personal major purchases:</strong> Keep for warranty period or lifetime of the product</li>
                <li><strong>Tax-deductible items:</strong> Keep for the duration required by your tax authority</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-3">
                Digital copies are generally acceptable, making it easier to store receipts long-term without physical clutter.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-5">
            <AccordionTrigger className="text-left">
              Can I use digital receipts for tax purposes?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                Yes, most tax authorities worldwide now accept digital receipts as valid documentation. The IRS in the United 
                States, HMRC in the UK, and most other tax agencies accept scanned or digitally-generated receipts as long as 
                they contain all the required information and are legible. Digital receipts offer several advantages: they're 
                easier to organize and store, less likely to fade or get damaged, and can be backed up for extra security. 
                However, it's important to ensure your digital receipts are stored securely and are easily retrievable in case 
                of an audit. Our platform generates PDF receipts that meet professional standards and are fully acceptable for 
                tax purposes.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-6">
            <AccordionTrigger className="text-left">
              How do I handle receipts for different currencies?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed mb-3">
                When dealing with multiple currencies, it's important to:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Always specify the currency used (USD, EUR, GBP, etc.)</li>
                <li>Use the correct currency symbol and format for that currency</li>
                <li>If converting currencies, note the exchange rate used and the date</li>
                <li>Keep receipts in their original currency for tax purposes</li>
                <li>Consult with your accountant about currency conversion for tax reporting</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-3">
                Our Global Receipt Generator automatically formats amounts according to each currency's standards, ensuring 
                your receipts are always professionally presented.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-7">
            <AccordionTrigger className="text-left">
              What are the different types of sales tax systems?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed mb-3">
                Different countries use different sales tax systems:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li><strong>VAT (Value Added Tax):</strong> Used in EU countries and many others worldwide. Typically ranges 
                from 15-27%. Applied at each stage of production and distribution.</li>
                <li><strong>GST (Goods and Services Tax):</strong> Used in countries like Canada, Australia, India, and 
                Singapore. Similar to VAT but with different implementation.</li>
                <li><strong>Sales Tax:</strong> Used in the USA and some other countries. Applied only at the final point of 
                sale to the end consumer.</li>
                <li><strong>No Sales Tax:</strong> Some jurisdictions have no general sales tax (e.g., Oregon, Delaware in USA)</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-3">
                Our platform supports all these tax systems and helps you calculate the correct tax amount based on your location.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-8">
            <AccordionTrigger className="text-left">
              Is this receipt generator free to use?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                Yes, our basic receipt generation service is completely free to use. You can create unlimited professional 
                receipts without any charges. There are no hidden fees, and you don't need to provide credit card information. 
                We believe in making professional business tools accessible to everyone, from solo entrepreneurs to established 
                businesses. Simply start creating receipts right away - no registration required for basic features.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-9">
            <AccordionTrigger className="text-left">
              Do I need to create an account to use the receipt generator?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                No account is required to start generating receipts immediately. However, creating an account allows you to 
                save your business information, access receipt history, and manage multiple business profiles. This makes it 
                faster to generate receipts in the future, as your business details will be pre-filled. Account creation is 
                optional and free.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-10">
            <AccordionTrigger className="text-left">
              Can I customize the appearance of my receipts?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                Yes, you can customize various aspects of your receipts including the receipt prefix, business information 
                layout, and which fields to include. While we maintain a professional standard format to ensure your receipts 
                are legally compliant, there's flexibility in how you present your business information and which optional 
                fields you choose to include. The generated PDF receipts are clean, professional, and suitable for any business 
                environment.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-11">
            <AccordionTrigger className="text-left">
              How secure is my business information?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                We take data security seriously. All information is transmitted using industry-standard encryption (HTTPS/TLS). 
                We do not sell or share your business information with third parties. Your data is stored securely and is only 
                used to provide the receipt generation service. We recommend reviewing our privacy policy for complete details 
                on how we handle and protect your information.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-12">
            <AccordionTrigger className="text-left">
              Can I use this for my online store or e-commerce business?
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-gray-600 leading-relaxed">
                Absolutely! Our receipt generator is perfect for online businesses, e-commerce stores, freelancers, service 
                providers, and brick-and-mortar retail. Whether you're selling physical products, digital goods, or services, 
                you can create professional receipts for your customers. The multi-currency support makes it especially useful 
                for businesses serving international customers.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </Card>

      <div className="bg-blue-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Still Have Questions?</h2>
        <p className="text-gray-600">
          Can't find the answer you're looking for? Feel free to reach out to our support team, and we'll be happy to help.
        </p>
      </div>
    </div>
  );
}
