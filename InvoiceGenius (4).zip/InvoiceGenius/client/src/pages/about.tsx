import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Receipt, Globe, Shield, Zap } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4" data-testid="about-title">
          About Global Receipt Generator
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Professional receipt generation for businesses worldwide with multi-currency and international tax support
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <Receipt className="h-6 w-6 text-blue-600" />
              <CardTitle>Our Mission</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 leading-relaxed">
              We empower small businesses, freelancers, and entrepreneurs around the world to create professional receipts 
              with ease. Our platform simplifies financial record-keeping and ensures compliance with international tax 
              regulations, making it easier for businesses to focus on growth rather than paperwork.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <Globe className="h-6 w-6 text-blue-600" />
              <CardTitle>Global Support</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 leading-relaxed">
              Operating in over 150 countries, our platform supports multiple currencies and various tax systems including 
              VAT, GST, and sales tax. Whether you're in New York, London, Tokyo, or Sydney, our receipt generator adapts 
              to your local business requirements and currency standards.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Why Choose Us?</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <Zap className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle className="text-lg">Fast & Easy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Generate professional receipts in seconds with our intuitive interface. No complicated setup or training required.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle className="text-lg">Secure & Reliable</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Your business data is protected with industry-standard security. We never share your information with third parties.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Receipt className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle className="text-lg">Professional Results</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Create receipts that look polished and professional, helping you build trust with your customers.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-8 mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
        <div className="space-y-4 text-gray-600 leading-relaxed">
          <p>
            Global Receipt Generator was founded with a simple goal: to make professional receipt creation accessible 
            to everyone, regardless of their location or business size. We recognized that many small business owners 
            and freelancers struggle with creating proper receipts that comply with local tax regulations while also 
            looking professional.
          </p>
          <p>
            After speaking with hundreds of business owners across different countries, we identified common pain points: 
            complicated accounting software, expensive tools with features they don't need, and the challenge of handling 
            multiple currencies and tax systems. We set out to build a solution that addresses these specific challenges.
          </p>
          <p>
            Today, thousands of businesses worldwide use our platform to generate receipts daily. From street vendors in 
            Bangkok to consulting firms in Toronto, our tool helps businesses of all sizes maintain proper financial records 
            and present a professional image to their customers.
          </p>
        </div>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Key Features</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Multi-Currency Support</h3>
              <p className="text-gray-600">
                Support for major world currencies including USD, EUR, GBP, JPY, CNY, INR, and many more. Automatic 
                currency formatting based on international standards.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Tax Compliance</h3>
              <p className="text-gray-600">
                Built-in support for various tax systems worldwide including VAT, GST, and sales tax. Configure tax 
                rates and calculations to match your local requirements.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Business Profiles</h3>
              <p className="text-gray-600">
                Save your business information for quick receipt generation. Manage multiple business profiles if you 
                operate several ventures.
              </p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Custom Receipt Numbering</h3>
              <p className="text-gray-600">
                Automatic receipt numbering with customizable prefixes. Keep your receipts organized and maintain 
                proper audit trails.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">PDF Export</h3>
              <p className="text-gray-600">
                Generate professional PDF receipts that you can email to customers, print, or store for your records. 
                High-quality output suitable for any business.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Mobile Friendly</h3>
              <p className="text-gray-600">
                Access our platform from any device - desktop, tablet, or smartphone. Generate receipts on the go 
                whenever you need them.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Values</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Simplicity First</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-600">
                We believe that creating professional receipts shouldn't require a degree in accounting or hours of training. 
                Our interface is designed to be intuitive and straightforward, allowing anyone to generate compliant receipts 
                in minutes, not hours.
              </p>
              <p className="text-gray-600">
                Every feature we add is carefully considered to ensure it adds value without adding complexity. We constantly 
                refine our platform based on user feedback to make the experience even more streamlined.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Global Accessibility</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-600">
                Business knows no borders in today's connected world. Whether you're a freelancer in Manila, a shop owner in 
                Lagos, or a consultant in Berlin, you deserve access to professional financial tools. Our multi-currency and 
                multi-tax system support ensures that businesses anywhere can use our platform effectively.
              </p>
              <p className="text-gray-600">
                We're committed to adding support for more currencies, tax systems, and regional requirements as we grow, 
                ensuring no business is left behind.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Privacy & Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-600">
                Your business data is yours alone. We employ industry-standard encryption for all data transmission and storage. 
                We never sell your information to third parties, and we don't use your data for advertising purposes. What you 
                create with our platform stays private and secure.
              </p>
              <p className="text-gray-600">
                Regular security audits, secure authentication systems, and compliance with international data protection 
                standards ensure your information remains protected at all times.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Continuous Improvement</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-600">
                We're never satisfied with "good enough." Our development team constantly works on improvements, new features, 
                and optimizations based on user feedback and emerging business needs. We release regular updates to ensure 
                our platform stays current with changing tax regulations and business practices.
              </p>
              <p className="text-gray-600">
                Your feedback directly shapes our roadmap. We listen to our users and prioritize features and improvements 
                that deliver the most value to real businesses.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-8 mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Technology & Innovation</h2>
        <div className="space-y-4 text-gray-600 leading-relaxed">
          <p>
            Global Receipt Generator is built on modern web technologies that ensure fast performance, reliability, and 
            accessibility across all devices. Our platform runs as a Progressive Web App (PWA), which means you can install 
            it on your smartphone or tablet and use it just like a native app—even with limited internet connectivity.
          </p>
          <p>
            We use real-time validation to catch errors before you submit, automatic calculations to eliminate math mistakes, 
            and smart defaults that remember your preferences to save time on every receipt you create. Behind the scenes, 
            our infrastructure is designed for speed and reliability, with automatic backups and redundancy ensuring your 
            data is always available when you need it.
          </p>
          <p>
            Our commitment to innovation means we're constantly exploring new technologies and features. Recent additions 
            include enhanced currency displays with visual indicators, improved PDF generation quality, and automatic receipt 
            number management to prevent duplicates. We're currently working on additional export formats, batch receipt 
            generation, and advanced reporting features based on user requests.
          </p>
        </div>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Who We Serve</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Freelancers & Consultants</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Independent professionals need to issue receipts quickly and professionally without the overhead of complex 
                accounting software. Our platform provides exactly what you need—nothing more, nothing less—allowing you to 
                focus on your work rather than paperwork.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Small Businesses</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Retail shops, service providers, restaurants, and other small businesses use our platform daily to generate 
                receipts for customers. Our multi-currency and tax support means you can serve customers from anywhere while 
                maintaining compliance with local regulations.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">International Businesses</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Companies operating across borders need tools that handle multiple currencies and tax jurisdictions seamlessly. 
                Our platform adapts to different countries' requirements, making it easier to manage international transactions 
                and maintain proper documentation.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Compliance & Standards</h2>
        <div className="space-y-4 text-gray-600 leading-relaxed">
          <p>
            We take compliance seriously. Our receipt templates are designed to meet the requirements of tax authorities 
            worldwide, including the IRS in the United States, HMRC in the United Kingdom, CRA in Canada, ATO in Australia, 
            and revenue services across Europe, Asia, and beyond.
          </p>
          <p>
            Every receipt generated through our platform includes all the essential elements required for tax compliance: 
            business information, transaction dates, itemized descriptions, tax calculations, and unique receipt numbers. 
            We stay updated on changing regulations and requirements to ensure your receipts remain compliant as laws evolve.
          </p>
          <p>
            For VAT-registered businesses in the EU, GST-registered businesses in countries like India and Singapore, and 
            businesses navigating sales tax in the United States, our platform handles the complexities of tax calculations 
            and proper documentation. We support both tax-inclusive and tax-exclusive pricing, multiple tax rates, and custom 
            tax configurations to match your specific requirements.
          </p>
        </div>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Educational Resources</h2>
        <div className="space-y-4 text-gray-600 leading-relaxed">
          <p>
            We believe in empowering our users with knowledge. That's why we maintain an extensive blog covering topics like 
            receipt best practices, international tax systems, financial record-keeping, compliance requirements, and business 
            management tips. These resources are freely available to everyone, whether you use our platform or not.
          </p>
          <p>
            Our goal is to help businesses worldwide understand the importance of proper financial documentation and provide 
            practical guidance for maintaining professional records. From understanding VAT versus GST to avoiding common 
            receipt mistakes, our educational content covers the full spectrum of receipt and invoice management topics.
          </p>
          <p>
            We regularly publish new articles, guides, and tutorials based on user questions and emerging topics in business 
            finance. Check our blog section regularly for new content, or subscribe to our newsletter for updates delivered 
            directly to your inbox.
          </p>
        </div>
      </div>

      <div className="bg-blue-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Ready to Get Started?</h2>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Join thousands of businesses worldwide who trust Global Receipt Generator for their receipt needs. 
          Start creating professional receipts today - no credit card required. Our platform is designed to grow 
          with your business, from your first receipt to your thousandth.
        </p>
        <div className="max-w-2xl mx-auto text-left bg-white rounded-lg p-6 mt-6">
          <h3 className="font-semibold text-lg text-gray-900 mb-3">What You Get:</h3>
          <ul className="space-y-2 text-gray-600">
            <li>✓ Unlimited receipt generation</li>
            <li>✓ Support for 150+ currencies</li>
            <li>✓ Multiple tax systems (VAT, GST, Sales Tax)</li>
            <li>✓ Professional PDF exports</li>
            <li>✓ Business profile management</li>
            <li>✓ Mobile-friendly interface</li>
            <li>✓ Secure data storage</li>
            <li>✓ Regular updates and improvements</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
