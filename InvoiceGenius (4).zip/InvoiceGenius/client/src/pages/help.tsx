import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { FileText, DollarSign, Settings, Download, Globe, Calculator } from "lucide-react";

export default function HelpPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4" data-testid="help-title">
          Help & User Guide
        </h1>
        <p className="text-xl text-gray-600">
          Learn how to make the most of Global Receipt Generator
        </p>
      </div>

      <Tabs defaultValue="getting-started" className="mb-12">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-8">
          <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
          <TabsTrigger value="creating-receipts">Create Receipts</TabsTrigger>
          <TabsTrigger value="business-info">Business Info</TabsTrigger>
          <TabsTrigger value="currencies">Currencies</TabsTrigger>
          <TabsTrigger value="taxes">Taxes</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="getting-started">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <FileText className="h-6 w-6 text-blue-600" />
                <CardTitle>Getting Started with Receipt Generation</CardTitle>
              </div>
              <CardDescription>
                Quick start guide to begin creating professional receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Step 1: Access the Receipt Generator</h3>
                <p className="text-gray-600 leading-relaxed">
                  Navigate to the "Generate Receipt" page from the main menu. You'll see a comprehensive form with all 
                  the fields needed to create a professional receipt. No registration is required to start generating 
                  receipts immediately.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 2: Set Up Your Business Information</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  For your first receipt, you'll need to enter your business information including:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                  <li>Business name and contact details</li>
                  <li>Business address</li>
                  <li>Phone number and email</li>
                  <li>Tax ID or registration number (if applicable)</li>
                </ul>
                <p className="text-gray-600 leading-relaxed mt-3">
                  This information can be saved in your business profile for faster receipt generation in the future.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 3: Enter Customer Information (Optional)</h3>
                <p className="text-gray-600 leading-relaxed">
                  Add your customer's details if you want them included on the receipt. This is optional but recommended 
                  for better record-keeping. Include name, contact information, and address as needed.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 4: Add Items or Services</h3>
                <p className="text-gray-600 leading-relaxed">
                  List each product or service provided, including description, quantity, and unit price. You can add 
                  multiple items to a single receipt. The subtotal will be calculated automatically.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 5: Configure Tax Settings</h3>
                <p className="text-gray-600 leading-relaxed">
                  Select your tax type (VAT, GST, Sales Tax, or None) and enter the applicable tax rate. The system 
                  will automatically calculate the tax amount and total.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 6: Add Payment Details</h3>
                <p className="text-gray-600 leading-relaxed">
                  Specify the payment method (cash, credit card, bank transfer, etc.), payment status, and any additional 
                  notes about the transaction.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Step 7: Generate and Download</h3>
                <p className="text-gray-600 leading-relaxed">
                  Click "Generate Receipt" to create your professional receipt. Preview it on screen, and download as a 
                  PDF for printing or digital distribution.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="creating-receipts">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <FileText className="h-6 w-6 text-blue-600" />
                <CardTitle>Creating Professional Receipts</CardTitle>
              </div>
              <CardDescription>
                Best practices for generating high-quality receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Receipt Numbering</h3>
                <p className="text-gray-600 leading-relaxed">
                  Each receipt should have a unique identifier. Our system automatically generates sequential receipt 
                  numbers with a customizable prefix (e.g., REC-001, REC-002). You can configure the prefix in your 
                  settings. This helps with organization and creates an audit trail for your business records.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Item Details</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  When adding items to your receipt, be clear and specific:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                  <li>Use descriptive names that customers will understand</li>
                  <li>Include relevant details (size, color, model, etc.)</li>
                  <li>Specify quantities accurately</li>
                  <li>List unit prices clearly</li>
                  <li>Double-check calculations before finalizing</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Date and Time</h3>
                <p className="text-gray-600 leading-relaxed">
                  The system automatically records the date and time of receipt generation. Ensure your device's clock 
                  is set correctly for accurate timestamps. This is important for record-keeping and warranty purposes.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Payment Information</h3>
                <p className="text-gray-600 leading-relaxed">
                  Always specify the payment method used (cash, credit card, debit card, bank transfer, check, etc.). 
                  This helps with reconciliation and provides a complete transaction record. You can also add payment 
                  notes for additional context, such as transaction IDs or check numbers.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Additional Notes</h3>
                <p className="text-gray-600 leading-relaxed">
                  Use the notes field to add important information such as return policies, warranty details, or special 
                  terms and conditions. Keep notes concise and professional.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="business-info">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Settings className="h-6 w-6 text-blue-600" />
                <CardTitle>Managing Business Information</CardTitle>
              </div>
              <CardDescription>
                Set up and manage your business profiles
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Creating Business Profiles</h3>
                <p className="text-gray-600 leading-relaxed">
                  Business profiles allow you to save your business information for quick access. You can create multiple 
                  profiles if you operate different businesses or divisions. Navigate to "Business Profiles" to create, 
                  edit, or delete profiles.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Required Information</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  A complete business profile should include:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                  <li><strong>Business Name:</strong> Your legal business name or DBA</li>
                  <li><strong>Contact Information:</strong> Phone, email, and website</li>
                  <li><strong>Physical Address:</strong> Street address, city, state/province, postal code, country</li>
                  <li><strong>Tax ID:</strong> Business tax identification number (if applicable)</li>
                  <li><strong>Registration Number:</strong> Business registration or company number (if applicable)</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Default Settings</h3>
                <p className="text-gray-600 leading-relaxed">
                  Set default values for currency, country, tax type, and tax rate. These defaults will be pre-selected 
                  when generating new receipts, saving you time on repetitive data entry.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Multiple Business Management</h3>
                <p className="text-gray-600 leading-relaxed">
                  If you run multiple businesses, create separate profiles for each. Switch between profiles easily when 
                  generating receipts. Each profile maintains its own receipt numbering sequence and settings.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="currencies">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Globe className="h-6 w-6 text-blue-600" />
                <CardTitle>Multi-Currency Support</CardTitle>
              </div>
              <CardDescription>
                Working with different currencies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Supported Currencies</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  Our platform supports major world currencies including:
                </p>
                <div className="grid md:grid-cols-2 gap-3 text-gray-600">
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>USD - US Dollar</li>
                    <li>EUR - Euro</li>
                    <li>GBP - British Pound</li>
                    <li>JPY - Japanese Yen</li>
                    <li>CNY - Chinese Yuan</li>
                    <li>INR - Indian Rupee</li>
                  </ul>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>CAD - Canadian Dollar</li>
                    <li>AUD - Australian Dollar</li>
                    <li>CHF - Swiss Franc</li>
                    <li>SGD - Singapore Dollar</li>
                    <li>AED - UAE Dirham</li>
                    <li>And many more...</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Currency Formatting</h3>
                <p className="text-gray-600 leading-relaxed">
                  Each currency is automatically formatted according to international standards:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4 mt-3">
                  <li>Correct symbol placement (before or after amount)</li>
                  <li>Proper use of decimal separators (. or ,)</li>
                  <li>Appropriate thousand separators</li>
                  <li>Correct decimal places for each currency</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Setting Your Default Currency</h3>
                <p className="text-gray-600 leading-relaxed">
                  Choose your primary currency in the receipt settings or business profile. This currency will be 
                  pre-selected for new receipts, though you can change it for individual transactions as needed.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">International Transactions</h3>
                <p className="text-gray-600 leading-relaxed">
                  When serving international customers, select the appropriate currency for the transaction. Always 
                  clearly indicate which currency is being used on the receipt to avoid confusion.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="taxes">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Calculator className="h-6 w-6 text-blue-600" />
                <CardTitle>Tax Configuration</CardTitle>
              </div>
              <CardDescription>
                Setting up and calculating taxes correctly
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Tax Types</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  Our system supports various tax systems used worldwide:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                  <li><strong>VAT (Value Added Tax):</strong> Common in European Union and many other countries</li>
                  <li><strong>GST (Goods and Services Tax):</strong> Used in Canada, Australia, India, Singapore, etc.</li>
                  <li><strong>Sales Tax:</strong> Used in United States and some other regions</li>
                  <li><strong>Custom:</strong> For other tax types or special situations</li>
                  <li><strong>None:</strong> For tax-exempt transactions or jurisdictions without sales tax</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Tax Rate Configuration</h3>
                <p className="text-gray-600 leading-relaxed">
                  Enter your local tax rate as a percentage. The system will automatically calculate the tax amount based 
                  on the subtotal. Common tax rates range from 5% to 27% depending on your location and tax type.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Tax-Inclusive vs Tax-Exclusive</h3>
                <p className="text-gray-600 leading-relaxed">
                  Choose whether your prices include tax (tax-inclusive) or if tax should be added on top (tax-exclusive):
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4 mt-3">
                  <li><strong>Tax-Exclusive:</strong> Tax is added to the subtotal to get the final total</li>
                  <li><strong>Tax-Inclusive:</strong> Prices already include tax; tax amount is extracted for display</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Tax Compliance</h3>
                <p className="text-gray-600 leading-relaxed">
                  Ensure you're using the correct tax rate for your jurisdiction. Tax rates can vary by:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4 mt-3">
                  <li>Country or state/province</li>
                  <li>Type of goods or services</li>
                  <li>Business registration status</li>
                  <li>Customer location (for some tax types)</li>
                </ul>
                <p className="text-gray-600 leading-relaxed mt-3">
                  Consult with a tax professional or your local tax authority if you're unsure about applicable rates.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="export">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Download className="h-6 w-6 text-blue-600" />
                <CardTitle>Exporting and Saving Receipts</CardTitle>
              </div>
              <CardDescription>
                Download, print, and share your receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">PDF Generation</h3>
                <p className="text-gray-600 leading-relaxed">
                  After generating a receipt, you can download it as a professional PDF document. The PDF format ensures 
                  your receipt looks the same on any device and can be easily printed or shared electronically.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Printing Receipts</h3>
                <p className="text-gray-600 leading-relaxed mb-3">
                  To print a receipt:
                </p>
                <ol className="list-decimal list-inside text-gray-600 space-y-2 ml-4">
                  <li>Generate and download the PDF</li>
                  <li>Open the PDF in your PDF viewer</li>
                  <li>Select Print from the file menu</li>
                  <li>Choose your printer and settings</li>
                  <li>Print on standard letter or A4 paper</li>
                </ol>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Sharing Receipts</h3>
                <p className="text-gray-600 leading-relaxed">
                  Share receipts with customers via email, messaging apps, or cloud storage services. The PDF format is 
                  universally compatible and professional. You can also upload receipts to your accounting software or 
                  cloud backup service.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Receipt Storage</h3>
                <p className="text-gray-600 leading-relaxed">
                  Organize your downloaded receipts in a systematic way:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4 mt-3">
                  <li>Create folders by month or year</li>
                  <li>Use descriptive file names (e.g., "REC-001-CustomerName-Date")</li>
                  <li>Backup receipts to cloud storage</li>
                  <li>Keep both digital and physical copies if required</li>
                  <li>Follow your local tax authority's retention requirements</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-3">Mobile Access</h3>
                <p className="text-gray-600 leading-relaxed">
                  Our platform works on mobile devices, allowing you to generate and access receipts on the go. Download 
                  PDFs directly to your phone or tablet for immediate access.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Tips</h2>
          <ul className="space-y-3 text-gray-600">
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Save your business information as a profile to speed up future receipt generation</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Double-check all amounts and calculations before finalizing receipts</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Use consistent receipt numbering for better record-keeping</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Include clear item descriptions that customers will understand</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Backup your receipts regularly to prevent data loss</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-600">•</span>
              <span>Verify you're using the correct tax rate for your jurisdiction</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6 bg-blue-50">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Need More Help?</h2>
          <p className="text-gray-600 mb-6">
            Can't find what you're looking for in our help guide? We're here to assist you with any questions or issues.
          </p>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              📧 Contact Support
            </Button>
            <Button variant="outline" className="w-full justify-start">
              📚 View FAQ
            </Button>
            <Button variant="outline" className="w-full justify-start">
              💬 Live Chat
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
