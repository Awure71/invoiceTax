import { useState } from "react";
import { ReceiptForm } from "@/components/receipt-form";
import { ReceiptPreview } from "@/components/receipt-preview";
import { type Receipt } from "@shared/schema";

export default function Home() {
  const [currentReceipt, setCurrentReceipt] = useState<Receipt | null>(null);

  const handleReceiptCreated = (receipt: Receipt) => {
    setCurrentReceipt(receipt);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold" data-testid="text-app-title">Global Receipt Generator</h1>
              <p className="text-primary-foreground/80 mt-1">Create professional receipts for any currency and region</p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          <ReceiptForm onReceiptCreated={handleReceiptCreated} />
          <ReceiptPreview receipt={currentReceipt} />
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-muted py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">Global Receipt Generator</h3>
              <p className="text-muted-foreground text-sm">Professional receipt generation for businesses worldwide with multi-currency support.</p>
            </div>
            <div>
              <h4 className="font-medium mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Multi-currency support</li>
                <li>International tax handling</li>
                <li>Professional PDF generation</li>
                <li>Custom receipt numbering</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Supported Currencies</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>USD, EUR, GBP, CAD</li>
                <li>AUD, JPY, CHF, CNY</li>
                <li>INR, NGN, and more</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Documentation</li>
                <li>API Reference</li>
                <li>Contact Support</li>
                <li>Feature Requests</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 mt-8">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <p>&copy; 2024 Global Receipt Generator. All rights reserved.</p>
              <div className="flex gap-4">
                <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
