import { type Receipt } from "@shared/schema";
import { formatCurrency, getCurrencySymbol } from "./currency";
import html2pdf from 'html2pdf.js';

export async function generateReceiptPDF(receipt: Receipt, download: boolean = false): Promise<void> {
  if (download) {
    // Generate actual PDF using html2pdf.js
    const html = generateReceiptHTML(receipt);
    
    // Create a temporary element to render the HTML
    const element = document.createElement('div');
    element.innerHTML = html;
    element.style.position = 'absolute';
    element.style.left = '-9999px';
    document.body.appendChild(element);
    
    try {
      await html2pdf()
        .from(element)
        .set({
          margin: 10,
          filename: `receipt-${receipt.receiptNumber}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        })
        .save();
    } finally {
      document.body.removeChild(element);
    }
  } else {
    // For print, use the browser's print functionality
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = generateReceiptHTML(receipt);
    
    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    
    // Wait for content to load then print
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
  }
}

function generateReceiptHTML(receipt: Receipt): string {
  const currencySymbol = getCurrencySymbol(receipt.currency);
  const itemsHTML = receipt.items.map(item => `
    <tr>
      <td style="padding: 4px 0; border-bottom: 1px solid #eee;">${item.name}</td>
      <td style="padding: 4px 0; text-align: center; border-bottom: 1px solid #eee;">${item.quantity}</td>
      <td style="padding: 4px 0; text-align: right; border-bottom: 1px solid #eee;">${formatCurrency(item.total, receipt.currency)}</td>
    </tr>
  `).join('');

  const taxDisplay = receipt.taxType !== 'none' && parseFloat(receipt.taxAmount || '0') > 0 ? `
    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
      <span>${receipt.taxType?.toUpperCase()} (${receipt.taxRate || '0'}%):</span>
      <span>${formatCurrency(parseFloat(receipt.taxAmount || '0'), receipt.currency)}</span>
    </div>
  ` : '';

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Receipt ${receipt.receiptNumber}</title>
      <style>
        body {
          font-family: 'Courier New', monospace;
          margin: 0;
          padding: 20px;
          background: white;
          color: black;
        }
        .receipt {
          max-width: 400px;
          margin: 0 auto;
          border: 2px solid #000;
          padding: 20px;
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #000;
          padding-bottom: 16px;
          margin-bottom: 16px;
        }
        .business-name {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 8px;
        }
        .details {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
          margin-bottom: 16px;
          font-size: 12px;
        }
        .items {
          border-top: 2px solid #000;
          padding-top: 16px;
        }
        .items table {
          width: 100%;
          font-size: 12px;
        }
        .items th {
          border-bottom: 1px solid #000;
          padding: 4px 0;
        }
        .totals {
          border-top: 2px solid #000;
          padding-top: 16px;
          margin-top: 16px;
        }
        .total-line {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .total-final {
          font-size: 16px;
          font-weight: bold;
          border-top: 1px solid #000;
          padding-top: 8px;
        }
        .footer {
          text-align: center;
          font-size: 10px;
          margin-top: 20px;
          padding-top: 16px;
          border-top: 1px solid #000;
        }
        @media print {
          body { margin: 0; padding: 10px; }
          .receipt { border: none; }
        }
      </style>
    </head>
    <body>
      <div class="receipt">
        <div class="header">
          <div class="business-name">${receipt.businessName}</div>
          <div style="font-size: 12px;">
            <div>${receipt.businessPhone}</div>
            ${receipt.businessEmail ? `<div>${receipt.businessEmail}</div>` : ''}
            ${receipt.businessAddress ? `<div>${receipt.businessAddress}</div>` : ''}
          </div>
        </div>

        <div class="details">
          <div>
            <div><strong>Receipt #:</strong> ${receipt.receiptNumber}</div>
            <div><strong>Date:</strong> ${new Date(receipt.paymentDate || new Date()).toLocaleDateString()}</div>
          </div>
          <div>
            ${receipt.customerName ? `
              <div><strong>Customer:</strong></div>
              <div>${receipt.customerName}</div>
              ${receipt.customerPhone ? `<div>${receipt.customerPhone}</div>` : ''}
            ` : ''}
          </div>
        </div>

        ${receipt.paymentMethods && receipt.paymentMethods.length > 0 ? `
          <div style="border-top: 1px solid #ddd; padding-top: 10px; margin-top: 10px; margin-bottom: 16px;">
            <div style="font-weight: bold; margin-bottom: 8px; font-size: 12px;">Payment Methods:</div>
            ${receipt.paymentMethods.map(payment => `
              <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px;">
                <span style="text-transform: capitalize;">${payment.method}:</span>
                <span style="font-weight: bold;">${formatCurrency(payment.amount, receipt.currency)}</span>
              </div>
            `).join('')}
          </div>
        ` : ''}

        <div class="items">
          <table>
            <thead>
              <tr>
                <th style="text-align: left;">Item</th>
                <th style="text-align: center;">Qty</th>
                <th style="text-align: right;">Amount</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHTML}
            </tbody>
          </table>
        </div>

        <div class="totals">
          <div class="total-line">
            <span>Subtotal:</span>
            <span>${formatCurrency(parseFloat(receipt.subtotal), receipt.currency)}</span>
          </div>
          ${taxDisplay}
          <div class="total-line total-final">
            <span>TOTAL:</span>
            <span>${formatCurrency(parseFloat(receipt.totalAmount), receipt.currency)}</span>
          </div>
        </div>

        <div class="footer">
          <div>Thank you for your business!</div>
          <div style="margin-top: 8px;">Generated by Global Receipt Generator</div>
          ${receipt.businessTaxId ? `<div>Tax ID: ${receipt.businessTaxId}</div>` : ''}
        </div>
      </div>
    </body>
    </html>
  `;
}
