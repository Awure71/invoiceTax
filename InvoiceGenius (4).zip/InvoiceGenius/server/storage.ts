import { type Receipt, type InsertReceipt, type ReceiptSettings, type InsertReceiptSettings, type ReceiptItem, type BusinessProfile, type InsertBusinessProfile, type ReceiptTemplate, type InsertReceiptTemplate, receipts, receiptSettings, businessProfiles, receiptTemplates } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getReceipt(id: string): Promise<Receipt | undefined>;
  getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined>;
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  getReceipts(limit?: number): Promise<Receipt[]>;
  getReceiptSettings(): Promise<ReceiptSettings | undefined>;
  updateReceiptSettings(settings: InsertReceiptSettings): Promise<ReceiptSettings>;
  getNextReceiptNumber(): Promise<string>;
  getBusinessProfile(id: string): Promise<BusinessProfile | undefined>;
  getBusinessProfiles(): Promise<BusinessProfile[]>;
  createBusinessProfile(profile: InsertBusinessProfile): Promise<BusinessProfile>;
  updateBusinessProfile(id: string, profile: Partial<InsertBusinessProfile>): Promise<BusinessProfile>;
  deleteBusinessProfile(id: string): Promise<void>;
  getDefaultBusinessProfile(): Promise<BusinessProfile | undefined>;
  setDefaultBusinessProfile(id: string): Promise<BusinessProfile>;
  getReceiptTemplate(id: string): Promise<ReceiptTemplate | undefined>;
  getReceiptTemplates(): Promise<ReceiptTemplate[]>;
  createReceiptTemplate(template: InsertReceiptTemplate): Promise<ReceiptTemplate>;
  updateReceiptTemplate(id: string, template: Partial<InsertReceiptTemplate>): Promise<ReceiptTemplate>;
  deleteReceiptTemplate(id: string): Promise<void>;
  getDefaultReceiptTemplate(): Promise<ReceiptTemplate | undefined>;
  setDefaultReceiptTemplate(id: string): Promise<ReceiptTemplate>;
}

export class DatabaseStorage implements IStorage {
  async getReceipt(id: string): Promise<Receipt | undefined> {
    const [receipt] = await db.select().from(receipts).where(eq(receipts.id, id));
    return receipt || undefined;
  }

  async getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined> {
    const [receipt] = await db.select().from(receipts).where(eq(receipts.receiptNumber, receiptNumber));
    return receipt || undefined;
  }

  async createReceipt(insertReceipt: InsertReceipt): Promise<Receipt> {
    // Ensure receipt number is unique by checking and incrementing if necessary
    let receiptNumber = insertReceipt.receiptNumber;
    let attempts = 0;
    const maxAttempts = 100;
    
    while (attempts < maxAttempts) {
      const existing = await this.getReceiptByNumber(receiptNumber);
      if (!existing) {
        break; // Found a unique number
      }
      
      // Extract number from receipt number (e.g., "REC-001" -> 1)
      const parts = receiptNumber.split('-');
      if (parts.length >= 2) {
        const currentNumber = parseInt(parts[parts.length - 1]) || 1;
        const newNumber = currentNumber + 1;
        const paddedNumber = newNumber.toString().padStart(3, "0");
        receiptNumber = `${parts.slice(0, -1).join('-')}-${paddedNumber}`;
      } else {
        // Fallback: append timestamp
        receiptNumber = `${receiptNumber}-${Date.now()}`;
        break;
      }
      
      attempts++;
    }
    
    const [receipt] = await db
      .insert(receipts)
      .values({ ...insertReceipt, receiptNumber })
      .returning();

    // Increment next receipt number in settings based on what we actually used
    const [currentSettings] = await db.select().from(receiptSettings).limit(1);
    if (currentSettings) {
      const parts = receiptNumber.split('-');
      if (parts.length >= 2) {
        const usedNumber = parseInt(parts[parts.length - 1]) || currentSettings.nextNumber;
        await db.update(receiptSettings)
          .set({ 
            nextNumber: usedNumber + 1,
            updatedAt: new Date()
          })
          .where(eq(receiptSettings.id, currentSettings.id));
      }
    }
    
    return receipt;
  }

  async getReceipts(limit = 50): Promise<Receipt[]> {
    const receiptsList = await db
      .select()
      .from(receipts)
      .orderBy(desc(receipts.createdAt))
      .limit(limit);
    
    return receiptsList;
  }

  async getReceiptSettings(): Promise<ReceiptSettings | undefined> {
    const [settings] = await db.select().from(receiptSettings).limit(1);
    
    // Create default settings if none exist
    if (!settings) {
      const [newSettings] = await db
        .insert(receiptSettings)
        .values({
          receiptPrefix: "REC",
          nextNumber: 1,
          businessName: "",
          businessPhone: "",
          defaultCurrency: "USD",
          defaultCountry: "US",
        })
        .returning();
      return newSettings;
    }
    
    return settings;
  }

  async updateReceiptSettings(newSettings: InsertReceiptSettings): Promise<ReceiptSettings> {
    const [existingSettings] = await db.select().from(receiptSettings).limit(1);
    
    if (!existingSettings) {
      // Create new settings
      const [settings] = await db
        .insert(receiptSettings)
        .values(newSettings)
        .returning();
      return settings;
    } else {
      // Update existing settings
      const [settings] = await db
        .update(receiptSettings)
        .set({ ...newSettings, updatedAt: new Date() })
        .where(eq(receiptSettings.id, existingSettings.id))
        .returning();
      return settings;
    }
  }

  async getNextReceiptNumber(): Promise<string> {
    const settings = await this.getReceiptSettings();
    if (!settings) {
      return "REC-001";
    }
    
    const paddedNumber = settings.nextNumber.toString().padStart(3, "0");
    return `${settings.receiptPrefix}-${paddedNumber}`;
  }

  async getBusinessProfile(id: string): Promise<BusinessProfile | undefined> {
    const [profile] = await db.select().from(businessProfiles).where(eq(businessProfiles.id, id));
    return profile || undefined;
  }

  async getBusinessProfiles(): Promise<BusinessProfile[]> {
    const profiles = await db
      .select()
      .from(businessProfiles)
      .orderBy(desc(businessProfiles.isDefault), desc(businessProfiles.createdAt));
    
    return profiles;
  }

  async createBusinessProfile(profile: InsertBusinessProfile): Promise<BusinessProfile> {
    // If this is the first profile or marked as default, ensure no other profiles are default
    if (profile.isDefault) {
      await db.update(businessProfiles).set({ isDefault: false });
    }

    const [newProfile] = await db
      .insert(businessProfiles)
      .values(profile)
      .returning();

    return newProfile;
  }

  async updateBusinessProfile(id: string, profile: Partial<InsertBusinessProfile>): Promise<BusinessProfile> {
    // If setting as default, unset all other defaults
    if (profile.isDefault) {
      await db.update(businessProfiles).set({ isDefault: false });
    }

    const [updatedProfile] = await db
      .update(businessProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(businessProfiles.id, id))
      .returning();

    return updatedProfile;
  }

  async deleteBusinessProfile(id: string): Promise<void> {
    await db.delete(businessProfiles).where(eq(businessProfiles.id, id));
  }

  async getDefaultBusinessProfile(): Promise<BusinessProfile | undefined> {
    const [profile] = await db
      .select()
      .from(businessProfiles)
      .where(eq(businessProfiles.isDefault, true))
      .limit(1);

    return profile || undefined;
  }

  async setDefaultBusinessProfile(id: string): Promise<BusinessProfile> {
    // First check if profile exists
    const [existingProfile] = await db.select().from(businessProfiles).where(eq(businessProfiles.id, id));
    if (!existingProfile) {
      throw new Error(`Business profile with ID ${id} not found`);
    }

    // Unset all other defaults
    await db.update(businessProfiles).set({ isDefault: false });
    
    // Set the specified profile as default
    const [profile] = await db
      .update(businessProfiles)
      .set({ isDefault: true, updatedAt: new Date() })
      .where(eq(businessProfiles.id, id))
      .returning();

    if (!profile) {
      throw new Error(`Failed to update business profile with ID ${id}`);
    }

    return profile;
  }

  // Receipt Template methods
  async getReceiptTemplate(id: string): Promise<ReceiptTemplate | undefined> {
    const [template] = await db.select().from(receiptTemplates).where(eq(receiptTemplates.id, id));
    return template || undefined;
  }

  async getReceiptTemplates(): Promise<ReceiptTemplate[]> {
    const templates = await db
      .select()
      .from(receiptTemplates)
      .orderBy(desc(receiptTemplates.isDefault), receiptTemplates.category, desc(receiptTemplates.createdAt));
    
    return templates;
  }

  async createReceiptTemplate(template: InsertReceiptTemplate): Promise<ReceiptTemplate> {
    // If this is marked as default, unset all other defaults
    if (template.isDefault) {
      await db.update(receiptTemplates).set({ isDefault: false });
    }

    const [newTemplate] = await db
      .insert(receiptTemplates)
      .values(template)
      .returning();

    return newTemplate;
  }

  async updateReceiptTemplate(id: string, template: Partial<InsertReceiptTemplate>): Promise<ReceiptTemplate> {
    // If setting as default, unset all other defaults
    if (template.isDefault) {
      await db.update(receiptTemplates).set({ isDefault: false });
    }

    const [updatedTemplate] = await db
      .update(receiptTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(receiptTemplates.id, id))
      .returning();

    return updatedTemplate;
  }

  async deleteReceiptTemplate(id: string): Promise<void> {
    await db.delete(receiptTemplates).where(eq(receiptTemplates.id, id));
  }

  async getDefaultReceiptTemplate(): Promise<ReceiptTemplate | undefined> {
    const [template] = await db
      .select()
      .from(receiptTemplates)
      .where(eq(receiptTemplates.isDefault, true))
      .limit(1);

    return template || undefined;
  }

  async setDefaultReceiptTemplate(id: string): Promise<ReceiptTemplate> {
    // First check if template exists
    const [existingTemplate] = await db.select().from(receiptTemplates).where(eq(receiptTemplates.id, id));
    if (!existingTemplate) {
      throw new Error(`Receipt template with ID ${id} not found`);
    }

    // Unset all other defaults
    await db.update(receiptTemplates).set({ isDefault: false });
    
    // Set the specified template as default
    const [template] = await db
      .update(receiptTemplates)
      .set({ isDefault: true, updatedAt: new Date() })
      .where(eq(receiptTemplates.id, id))
      .returning();

    if (!template) {
      throw new Error(`Failed to update receipt template with ID ${id}`);
    }

    return template;
  }
}

export const storage = new DatabaseStorage();
