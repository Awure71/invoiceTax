import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReceiptSchema, insertReceiptSettingsSchema, insertBusinessProfileSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get receipt settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getReceiptSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get settings" });
    }
  });

  // Update receipt settings
  app.put("/api/settings", async (req, res) => {
    try {
      const validatedData = insertReceiptSettingsSchema.parse(req.body);
      const settings = await storage.updateReceiptSettings(validatedData);
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  // Get next receipt number
  app.get("/api/receipts/next-number", async (req, res) => {
    try {
      const nextNumber = await storage.getNextReceiptNumber();
      res.json({ receiptNumber: nextNumber });
    } catch (error) {
      res.status(500).json({ message: "Failed to get next receipt number" });
    }
  });

  // Create receipt
  app.post("/api/receipts", async (req, res) => {
    try {
      const validatedData = insertReceiptSchema.parse(req.body);
      const receipt = await storage.createReceipt(validatedData);
      res.json(receipt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Receipt validation error:", error.errors);
        res.status(400).json({ message: "Invalid receipt data", errors: error.errors });
      } else {
        console.error("Error creating receipt:", error);
        res.status(500).json({ message: "Failed to create receipt", error: error instanceof Error ? error.message : "Unknown error" });
      }
    }
  });

  // Get receipts
  app.get("/api/receipts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const receipts = await storage.getReceipts(limit);
      res.json(receipts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get receipts" });
    }
  });

  // Get receipt by ID
  app.get("/api/receipts/:id", async (req, res) => {
    try {
      const receipt = await storage.getReceipt(req.params.id);
      if (!receipt) {
        res.status(404).json({ message: "Receipt not found" });
        return;
      }
      res.json(receipt);
    } catch (error) {
      res.status(500).json({ message: "Failed to get receipt" });
    }
  });

  // Business Profile Routes
  
  // Get all business profiles
  app.get("/api/business-profiles", async (req, res) => {
    try {
      const profiles = await storage.getBusinessProfiles();
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ message: "Failed to get business profiles" });
    }
  });

  // Get business profile by ID
  app.get("/api/business-profiles/:id", async (req, res) => {
    try {
      const profile = await storage.getBusinessProfile(req.params.id);
      if (!profile) {
        res.status(404).json({ message: "Business profile not found" });
        return;
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get business profile" });
    }
  });

  // Create business profile
  app.post("/api/business-profiles", async (req, res) => {
    try {
      const validatedData = insertBusinessProfileSchema.parse(req.body);
      const profile = await storage.createBusinessProfile(validatedData);
      res.json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid business profile data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create business profile" });
      }
    }
  });

  // Update business profile
  app.put("/api/business-profiles/:id", async (req, res) => {
    try {
      const validatedData = insertBusinessProfileSchema.partial().parse(req.body);
      const profile = await storage.updateBusinessProfile(req.params.id, validatedData);
      res.json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid business profile data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update business profile" });
      }
    }
  });

  // Delete business profile
  app.delete("/api/business-profiles/:id", async (req, res) => {
    try {
      await storage.deleteBusinessProfile(req.params.id);
      res.json({ message: "Business profile deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete business profile" });
    }
  });

  // Get default business profile
  app.get("/api/business-profiles/default/profile", async (req, res) => {
    try {
      const profile = await storage.getDefaultBusinessProfile();
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get default business profile" });
    }
  });

  // Set default business profile
  app.put("/api/business-profiles/:id/set-default", async (req, res) => {
    try {
      const profile = await storage.setDefaultBusinessProfile(req.params.id);
      res.json(profile);
    } catch (error) {
      console.error("Error setting default business profile:", error);
      res.status(500).json({ 
        message: "Failed to set default business profile",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
