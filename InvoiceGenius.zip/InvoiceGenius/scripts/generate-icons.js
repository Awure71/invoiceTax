import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import sharp from 'sharp';

// PNG icon generator using Sharp to convert SVG to PNG
const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const iconColor = '#3B82F6';

function generateSVGIcon(size, isMaskable = false) {
  const padding = isMaskable ? size * 0.2 : size * 0.1;
  const innerSize = size - (padding * 2);
  const fontSize = innerSize * 0.5;
  
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <rect width="${size}" height="${size}" fill="${iconColor}" rx="${isMaskable ? 0 : size * 0.1}"/>
  <g transform="translate(${padding}, ${padding})">
    <rect x="${innerSize * 0.15}" y="${innerSize * 0.1}" width="${innerSize * 0.7}" height="${innerSize * 0.8}" 
          fill="white" rx="${innerSize * 0.05}" stroke="white" stroke-width="${innerSize * 0.02}"/>
    <line x1="${innerSize * 0.25}" y1="${innerSize * 0.25}" x2="${innerSize * 0.75}" y2="${innerSize * 0.25}" 
          stroke="${iconColor}" stroke-width="${innerSize * 0.04}" stroke-linecap="round"/>
    <line x1="${innerSize * 0.25}" y1="${innerSize * 0.4}" x2="${innerSize * 0.75}" y2="${innerSize * 0.4}" 
          stroke="${iconColor}" stroke-width="${innerSize * 0.04}" stroke-linecap="round"/>
    <line x1="${innerSize * 0.25}" y1="${innerSize * 0.55}" x2="${innerSize * 0.75}" y2="${innerSize * 0.55}" 
          stroke="${iconColor}" stroke-width="${innerSize * 0.04}" stroke-linecap="round"/>
    <path d="M ${innerSize * 0.3} ${innerSize * 0.75} L ${innerSize * 0.7} ${innerSize * 0.75}" 
          stroke="${iconColor}" stroke-width="${innerSize * 0.06}" stroke-linecap="round"/>
  </g>
</svg>`;
}

async function convertSvgToPng(svgBuffer, size, outputPath) {
  await sharp(svgBuffer)
    .resize(size, size)
    .png({
      compressionLevel: 9,
      quality: 100
    })
    .toFile(outputPath);
}

async function generateIcons() {
  const iconsDir = join(process.cwd(), 'client', 'public', 'icons');
  mkdirSync(iconsDir, { recursive: true });

  // Generate regular icons
  for (const size of sizes) {
    const svg = generateSVGIcon(size, false);
    const svgBuffer = Buffer.from(svg);
    const pngPath = join(iconsDir, `icon-${size}x${size}.png`);
    
    await convertSvgToPng(svgBuffer, size, pngPath);
    console.log(`✓ Generated icon-${size}x${size}.png`);
  }

  // Generate maskable icon (512x512 only)
  const maskableSvg = generateSVGIcon(512, true);
  const maskableSvgBuffer = Buffer.from(maskableSvg);
  const maskablePngPath = join(iconsDir, 'icon-512x512-maskable.png');
  
  await convertSvgToPng(maskableSvgBuffer, 512, maskablePngPath);
  console.log('✓ Generated icon-512x512-maskable.png');

  // Generate Apple touch icon (180x180)
  const appleSvg = generateSVGIcon(180, false);
  const appleSvgBuffer = Buffer.from(appleSvg);
  const applePngPath = join(iconsDir, 'apple-touch-icon.png');
  
  await convertSvgToPng(appleSvgBuffer, 180, applePngPath);
  console.log('✓ Generated apple-touch-icon.png');

  // Generate favicon (32x32 and 16x16)
  const faviconSvg32 = generateSVGIcon(32, false);
  const faviconSvgBuffer32 = Buffer.from(faviconSvg32);
  const faviconPngPath32 = join(iconsDir, 'favicon-32x32.png');
  
  await convertSvgToPng(faviconSvgBuffer32, 32, faviconPngPath32);
  console.log('✓ Generated favicon-32x32.png');

  const faviconSvg16 = generateSVGIcon(16, false);
  const faviconSvgBuffer16 = Buffer.from(faviconSvg16);
  const faviconPngPath16 = join(iconsDir, 'favicon-16x16.png');
  
  await convertSvgToPng(faviconSvgBuffer16, 16, faviconPngPath16);
  console.log('✓ Generated favicon-16x16.png');

  console.log('\n✅ All PNG icons generated successfully!');
}

generateIcons().catch(console.error);
