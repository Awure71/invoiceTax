# Overview

This is a Global Receipt Generator application built with React and Express, designed to create professional receipts with multi-currency and international tax support. The application allows businesses to generate, preview, and export receipts in various formats while handling different currencies, tax systems, and business requirements across different countries.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React using TypeScript and follows a component-based architecture:

- **UI Framework**: React with TypeScript, using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: React Hook Form for form handling, TanStack React Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Component Structure**: Modular components with separate UI components, form components, and page components

## Backend Architecture
The server-side uses Express.js with TypeScript in a REST API pattern:

- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints for receipt management and settings
- **Data Storage**: Currently using in-memory storage with an interface pattern for easy database migration
- **Development Setup**: Hot-reload development server with Vite integration

## Data Storage Solutions
The application uses a flexible storage pattern:

- **Current Implementation**: In-memory storage for development/testing
- **Database Ready**: Drizzle ORM configured for PostgreSQL with schema definitions
- **Migration Support**: Database migrations configured for production deployment
- **Schema Design**: Structured tables for receipts, receipt settings, and business information

## Key Features Architecture

### Multi-Currency Support
- Predefined currency definitions with symbols and country flags
- Currency selection components with visual indicators
- Automatic currency formatting based on locale standards

### Tax System Handling
- Support for various tax types (VAT, GST, Sales Tax, Custom)
- Configurable tax rates and inclusive/exclusive calculations
- Country-specific tax handling capabilities

### Receipt Generation
- Dynamic form validation using Zod schemas
- Real-time preview functionality
- PDF generation capabilities for printing and sharing
- Customizable receipt numbering system

### Business Configuration
- Persistent business settings and preferences
- Default values for commonly used fields
- Receipt prefix and numbering customization

### Progressive Web App (PWA)
- **Installable on Android**: Full PWA support with manifest and service worker
- **Offline Capability**: Service worker caches assets for offline use
- **App Icons**: PNG icons in multiple sizes (72x72 to 512x512) including maskable icon
- **Install Prompt**: Custom UI component to prompt users to install the app
- **Caching Strategy**: Cache-first for static assets, network-first for API requests
- **Auto-update**: Service worker handles updates with user notification

## Development and Build Process
- **Development**: Hot-reload server with Vite integration
- **Build**: Separate client and server builds with esbuild for server bundling
- **Type Safety**: Shared TypeScript schemas between client and server
- **Code Quality**: ESM modules throughout with strict TypeScript configuration

# External Dependencies

## UI and Styling
- **Radix UI**: Accessible component primitives for form elements and interactions
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for managing conditional CSS classes

## Data and State Management
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation and schema definition
- **Drizzle ORM**: Type-safe SQL query builder and schema management

## Database Integration
- **PostgreSQL**: Primary database (configured via Drizzle)
- **Neon Database**: Serverless PostgreSQL provider integration
- **Connect-pg-simple**: PostgreSQL session store for Express sessions

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Static type checking
- **ESBuild**: Fast bundling for production builds
- **TSX**: TypeScript execution for development

## Utilities and Libraries
- **Date-fns**: Date manipulation and formatting
- **Nanoid**: Unique ID generation
- **CLSX**: Conditional className utility
- **Wouter**: Lightweight React router
- **Sharp**: High-performance image processing for PWA icon generation