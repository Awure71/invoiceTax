import { usePWA } from '@/hooks/use-pwa';
import { Button } from '@/components/ui/button';
import { Download, X } from 'lucide-react';
import { useState } from 'react';

export function PWAInstallPrompt() {
  const { isInstallable, isInstalled, promptInstall } = usePWA();
  const [isDismissed, setIsDismissed] = useState(false);

  if (isInstalled || !isInstallable || isDismissed) {
    return null;
  }

  const handleInstall = async () => {
    const installed = await promptInstall();
    if (installed) {
      setIsDismissed(true);
    }
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-white border border-gray-200 rounded-lg shadow-lg p-4 z-50" data-testid="pwa-install-prompt">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 flex-1">
          <div className="bg-blue-100 p-2 rounded-lg">
            <Download className="h-5 w-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 text-sm" data-testid="install-prompt-title">
              Install App
            </h3>
            <p className="text-xs text-gray-600 mt-1" data-testid="install-prompt-description">
              Install our app for quick access and offline use
            </p>
            <div className="flex gap-2 mt-3">
              <Button 
                size="sm" 
                onClick={handleInstall}
                data-testid="button-install-app"
              >
                Install
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setIsDismissed(true)}
                data-testid="button-dismiss-install"
              >
                Not now
              </Button>
            </div>
          </div>
        </div>
        <button
          onClick={() => setIsDismissed(true)}
          className="text-gray-400 hover:text-gray-600"
          aria-label="Close"
          data-testid="button-close-install-prompt"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
