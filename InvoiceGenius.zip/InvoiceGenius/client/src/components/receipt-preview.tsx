import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Receipt } from "@shared/schema";
import { formatCurrency } from "@/lib/currency";
import { generateReceiptPDF } from "@/lib/pdf-generator";
import { Printer, Mail, Share2 } from "lucide-react";

interface ReceiptPreviewProps {
  receipt: Receipt | null;
}

export function ReceiptPreview({ receipt }: ReceiptPreviewProps) {
  if (!receipt) {
    return (
      <div className="lg:sticky lg:top-8">
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <p>Receipt preview will appear here after generating a receipt</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handlePrint = () => {
    generateReceiptPDF(receipt);
  };

  const handleEmail = () => {
    // TODO: Implement email functionality
    console.log("Email receipt");
  };

  const handleShare = () => {
    // TODO: Implement share functionality
    console.log("Share receipt");
  };

  return (
    <div className="lg:sticky lg:top-8">
      <Card>
        <CardContent className="p-8">
          <div className="max-w-md mx-auto bg-white text-black p-6 rounded-lg shadow-sm" style={{ fontFamily: 'Courier New, monospace' }}>
            
            {/* Receipt Header */}
            <div className="text-center border-b-2 border-gray-800 pb-4 mb-4">
              <h1 className="text-xl font-bold" data-testid="preview-business-name">{receipt.businessName}</h1>
              <div className="text-sm mt-2">
                <p data-testid="preview-business-phone">{receipt.businessPhone}</p>
                {receipt.businessEmail && <p data-testid="preview-business-email">{receipt.businessEmail}</p>}
                {receipt.businessAddress && (
                  <p data-testid="preview-business-address" className="whitespace-pre-line">{receipt.businessAddress}</p>
                )}
              </div>
            </div>

            {/* Receipt Details */}
            <div className="grid grid-cols-2 gap-4 text-sm mb-4">
              <div>
                <p><strong>Receipt #:</strong> <span data-testid="preview-receipt-number">{receipt.receiptNumber}</span></p>
                <p><strong>Date:</strong> <span data-testid="preview-date">{new Date(receipt.paymentDate || new Date()).toLocaleDateString()}</span></p>
                <p><strong>Payment:</strong> <span data-testid="preview-payment-method">{receipt.paymentMethod}</span></p>
              </div>
              <div>
                {receipt.customerName && (
                  <>
                    <p><strong>Customer:</strong></p>
                    <p data-testid="preview-customer-name">{receipt.customerName}</p>
                    {receipt.customerPhone && <p data-testid="preview-customer-phone">{receipt.customerPhone}</p>}
                  </>
                )}
              </div>
            </div>

            {/* Items */}
            <div className="border-t-2 border-gray-800 pt-4">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-400">
                    <th className="text-left py-1">Item</th>
                    <th className="text-center py-1">Qty</th>
                    <th className="text-right py-1">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {receipt.items.map((item, index) => (
                    <tr key={item.id}>
                      <td className="py-1" data-testid={`preview-item-name-${index}`}>{item.name}</td>
                      <td className="text-center" data-testid={`preview-item-quantity-${index}`}>{item.quantity}</td>
                      <td className="text-right" data-testid={`preview-item-total-${index}`}>
                        {formatCurrency(item.total, receipt.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="border-t-2 border-gray-800 pt-4 mt-4">
              <div className="flex justify-between mb-2">
                <span>Subtotal:</span>
                <span data-testid="preview-subtotal">{formatCurrency(parseFloat(receipt.subtotal), receipt.currency)}</span>
              </div>
              {receipt.taxType !== 'none' && parseFloat(receipt.taxAmount || '0') > 0 && (
                <div className="flex justify-between mb-2">
                  <span>{receipt.taxType?.toUpperCase()} ({receipt.taxRate || '0'}%):</span>
                  <span data-testid="preview-tax">{formatCurrency(parseFloat(receipt.taxAmount || '0'), receipt.currency)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold border-t border-gray-400 pt-2">
                <span>TOTAL:</span>
                <span data-testid="preview-total">{formatCurrency(parseFloat(receipt.totalAmount), receipt.currency)}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="text-center text-xs mt-6 pt-4 border-t border-gray-400">
              <p>Thank you for your business!</p>
              <p className="mt-2">Generated by Global Receipt Generator</p>
              {receipt.businessTaxId && <p data-testid="preview-tax-id">Tax ID: {receipt.businessTaxId}</p>}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Preview Actions */}
      <div className="mt-4 flex gap-2">
        <Button variant="outline" onClick={handlePrint} className="flex-1" data-testid="button-print">
          <Printer className="h-4 w-4 mr-2" />
          Printer
        </Button>
        <Button variant="outline" onClick={handleEmail} className="flex-1" data-testid="button-email">
          <Mail className="h-4 w-4 mr-2" />
          Email
        </Button>
        <Button variant="outline" onClick={handleShare} className="flex-1" data-testid="button-share">
          <Share2 className="h-4 w-4 mr-2" />
          Share
        </Button>
      </div>
    </div>
  );
}
