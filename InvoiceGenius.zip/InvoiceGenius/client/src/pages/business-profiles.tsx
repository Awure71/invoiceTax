import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, Building, Edit, Trash2, Star, Upload, Palette } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBusinessProfileSchema, type BusinessProfile, type InsertBusinessProfile } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function BusinessProfilesPage() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<BusinessProfile | null>(null);
  const { toast } = useToast();

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ['/api/business-profiles'],
  });

  const createProfileMutation = useMutation({
    mutationFn: (data: InsertBusinessProfile) => 
      apiRequest('POST', '/api/business-profiles', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/business-profiles'] });
      setIsCreateDialogOpen(false);
      toast({ title: "Success", description: "Business profile created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create business profile", variant: "destructive" });
    }
  });

  const updateProfileMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertBusinessProfile> }) =>
      apiRequest('PUT', `/api/business-profiles/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/business-profiles'] });
      setIsEditDialogOpen(false);
      setEditingProfile(null);
      toast({ title: "Success", description: "Business profile updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update business profile", variant: "destructive" });
    }
  });

  const deleteProfileMutation = useMutation({
    mutationFn: (id: string) => 
      apiRequest('DELETE', `/api/business-profiles/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/business-profiles'] });
      toast({ title: "Success", description: "Business profile deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete business profile", variant: "destructive" });
    }
  });

  const setDefaultMutation = useMutation({
    mutationFn: (id: string) => 
      apiRequest('PUT', `/api/business-profiles/${id}/set-default`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/business-profiles'] });
      toast({ title: "Success", description: "Default business profile updated" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to set default profile", variant: "destructive" });
    }
  });

  const createForm = useForm<InsertBusinessProfile>({
    resolver: zodResolver(insertBusinessProfileSchema),
    defaultValues: {
      name: "",
      description: "",
      phone: "",
      email: "",
      address: "",
      website: "",
      taxId: "",
      regNumber: "",
      industry: "",
      primaryColor: "#3b82f6",
      secondaryColor: "#f3f4f6",
      isDefault: false,
    },
  });

  const editForm = useForm<InsertBusinessProfile>({
    resolver: zodResolver(insertBusinessProfileSchema),
    defaultValues: {
      name: "",
      description: "",
      phone: "",
      email: "",
      address: "",
      website: "",
      taxId: "",
      regNumber: "",
      industry: "",
      primaryColor: "#3b82f6",
      secondaryColor: "#f3f4f6",
      isDefault: false,
    },
  });

  const onCreateSubmit = (data: InsertBusinessProfile) => {
    createProfileMutation.mutate(data);
  };

  const onEditSubmit = (data: InsertBusinessProfile) => {
    if (editingProfile) {
      updateProfileMutation.mutate({ id: editingProfile.id, data });
    }
  };

  const handleEdit = (profile: BusinessProfile) => {
    setEditingProfile(profile);
    editForm.reset({
      name: profile.name,
      description: profile.description || "",
      phone: profile.phone,
      email: profile.email || "",
      address: profile.address || "",
      website: profile.website || "",
      taxId: profile.taxId || "",
      regNumber: profile.regNumber || "",
      industry: profile.industry || "",
      primaryColor: profile.primaryColor || "#3b82f6",
      secondaryColor: profile.secondaryColor || "#f3f4f6",
      isDefault: profile.isDefault || false,
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    deleteProfileMutation.mutate(id);
  };

  const handleSetDefault = (id: string) => {
    setDefaultMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-center items-center h-32">
          <div className="text-lg">Loading business profiles...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Business Profiles</h1>
          <p className="text-muted-foreground mt-2">
            Manage your business profiles for different receipt types and branding
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-profile">
              <Plus className="mr-2 h-4 w-4" />
              New Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Business Profile</DialogTitle>
              <DialogDescription>
                Create a new business profile with custom branding and information
              </DialogDescription>
            </DialogHeader>
            <Form {...createForm}>
              <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name *</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-profile-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone *</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-profile-phone" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={createForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} data-testid="input-profile-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="website"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-profile-website" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={createForm.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Textarea {...field} data-testid="input-profile-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea {...field} data-testid="input-profile-description" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={createForm.control}
                    name="industry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Industry</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger data-testid="select-profile-industry">
                              <SelectValue placeholder="Select industry" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="retail">Retail</SelectItem>
                              <SelectItem value="service">Service</SelectItem>
                              <SelectItem value="consulting">Consulting</SelectItem>
                              <SelectItem value="manufacturing">Manufacturing</SelectItem>
                              <SelectItem value="technology">Technology</SelectItem>
                              <SelectItem value="healthcare">Healthcare</SelectItem>
                              <SelectItem value="education">Education</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="taxId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tax ID</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-profile-tax-id" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="regNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Registration Number</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-profile-reg-number" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={createForm.control}
                    name="primaryColor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Primary Color</FormLabel>
                        <FormControl>
                          <div className="flex gap-2">
                            <Input type="color" {...field} className="w-16 h-10" data-testid="input-profile-primary-color" />
                            <Input {...field} placeholder="#3b82f6" data-testid="input-profile-primary-color-text" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="secondaryColor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secondary Color</FormLabel>
                        <FormControl>
                          <div className="flex gap-2">
                            <Input type="color" {...field} className="w-16 h-10" data-testid="input-profile-secondary-color" />
                            <Input {...field} placeholder="#f3f4f6" data-testid="input-profile-secondary-color-text" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={createProfileMutation.isPending}
                    data-testid="button-submit-profile"
                  >
                    {createProfileMutation.isPending ? "Creating..." : "Create Profile"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {profiles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <Building className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No business profiles yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create your first business profile to get started with customized receipts
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-create-first-profile">
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Profile
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {profiles.map((profile: BusinessProfile) => (
            <Card key={profile.id} className="relative">
              {profile.isDefault && (
                <Badge className="absolute top-3 right-3" variant="default" data-testid={`badge-default-${profile.id}`}>
                  <Star className="mr-1 h-3 w-3" />
                  Default
                </Badge>
              )}
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl" data-testid={`text-profile-name-${profile.id}`}>
                      {profile.name}
                    </CardTitle>
                    {profile.industry && (
                      <CardDescription className="capitalize" data-testid={`text-profile-industry-${profile.id}`}>
                        {profile.industry}
                      </CardDescription>
                    )}
                  </div>
                </div>
                {profile.description && (
                  <p className="text-sm text-muted-foreground mt-2" data-testid={`text-profile-description-${profile.id}`}>
                    {profile.description}
                  </p>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div data-testid={`text-profile-phone-${profile.id}`}>📞 {profile.phone}</div>
                  {profile.email && (
                    <div data-testid={`text-profile-email-${profile.id}`}>📧 {profile.email}</div>
                  )}
                  {profile.address && (
                    <div data-testid={`text-profile-address-${profile.id}`}>📍 {profile.address}</div>
                  )}
                  {profile.website && (
                    <div data-testid={`text-profile-website-${profile.id}`}>🌐 {profile.website}</div>
                  )}
                </div>
                <div className="flex gap-2 mt-4">
                  <div 
                    className="w-4 h-4 rounded border"
                    style={{ backgroundColor: profile.primaryColor }}
                    title="Primary Color"
                  />
                  <div 
                    className="w-4 h-4 rounded border"
                    style={{ backgroundColor: profile.secondaryColor }}
                    title="Secondary Color"
                  />
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex gap-2 w-full">
                  {!profile.isDefault && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleSetDefault(profile.id)}
                      data-testid={`button-set-default-${profile.id}`}
                    >
                      <Star className="mr-1 h-3 w-3" />
                      Set Default
                    </Button>
                  )}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleEdit(profile)}
                    data-testid={`button-edit-${profile.id}`}
                  >
                    <Edit className="mr-1 h-3 w-3" />
                    Edit
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" data-testid={`button-delete-${profile.id}`}>
                        <Trash2 className="mr-1 h-3 w-3" />
                        Delete
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Business Profile</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{profile.name}"? This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={() => handleDelete(profile.id)}
                          data-testid={`button-confirm-delete-${profile.id}`}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Business Profile</DialogTitle>
            <DialogDescription>
              Update your business profile information and branding
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              {/* Similar form fields as create form */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Name *</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-edit-profile-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone *</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-edit-profile-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} data-testid="input-edit-profile-email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="website"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Website</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-edit-profile-website" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={editForm.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-edit-profile-address" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="primaryColor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Primary Color</FormLabel>
                      <FormControl>
                        <div className="flex gap-2">
                          <Input type="color" {...field} className="w-16 h-10" data-testid="input-edit-profile-primary-color" />
                          <Input {...field} placeholder="#3b82f6" data-testid="input-edit-profile-primary-color-text" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="secondaryColor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Secondary Color</FormLabel>
                      <FormControl>
                        <div className="flex gap-2">
                          <Input type="color" {...field} className="w-16 h-10" data-testid="input-edit-profile-secondary-color" />
                          <Input {...field} placeholder="#f3f4f6" data-testid="input-edit-profile-secondary-color-text" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={updateProfileMutation.isPending}
                  data-testid="button-update-profile"
                >
                  {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}