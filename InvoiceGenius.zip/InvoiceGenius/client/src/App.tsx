import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import Home from "@/pages/home";
import { BusinessProfilesPage } from "@/pages/business-profiles";
import NotFound from "@/pages/not-found";
import { Receipt, Building } from "lucide-react";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";

function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="border-b border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Receipt className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Global Receipt Generator</span>
            </div>
            <div className="hidden sm:ml-8 sm:flex sm:space-x-8">
              <Link href="/">
                <Button
                  variant={location === "/" ? "default" : "ghost"}
                  className="inline-flex items-center px-1 pt-1"
                  data-testid="nav-home"
                >
                  <Receipt className="mr-2 h-4 w-4" />
                  Generate Receipt
                </Button>
              </Link>
              <Link href="/business-profiles">
                <Button
                  variant={location === "/business-profiles" ? "default" : "ghost"}
                  className="inline-flex items-center px-1 pt-1"
                  data-testid="nav-business-profiles"
                >
                  <Building className="mr-2 h-4 w-4" />
                  Business Profiles
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function Router() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/business-profiles" component={BusinessProfilesPage} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <PWAInstallPrompt />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
