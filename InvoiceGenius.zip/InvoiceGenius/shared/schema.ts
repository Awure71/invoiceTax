import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const receipts = pgTable("receipts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  receiptNumber: text("receipt_number").notNull().unique(),
  businessName: text("business_name").notNull(),
  businessPhone: text("business_phone").notNull(),
  businessEmail: text("business_email"),
  businessAddress: text("business_address"),
  businessTaxId: text("business_tax_id"),
  businessRegNumber: text("business_reg_number"),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerEmail: text("customer_email"),
  customerAddress: text("customer_address"),
  currency: text("currency").notNull().default("USD"),
  country: text("country").notNull().default("US"),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
  taxType: text("tax_type").default("none"),
  taxRate: decimal("tax_rate", { precision: 5, scale: 2 }).default("0"),
  taxAmount: decimal("tax_amount", { precision: 12, scale: 2 }).default("0"),
  taxInclusive: boolean("tax_inclusive").default(false),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
  paymentMethod: text("payment_method").notNull(),
  paymentStatus: text("payment_status").notNull().default("paid"),
  paymentDate: timestamp("payment_date").defaultNow(),
  paymentNotes: text("payment_notes"),
  items: jsonb("items").notNull().$type<ReceiptItem[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const receiptSettings = pgTable("receipt_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  receiptPrefix: text("receipt_prefix").notNull().default("REC"),
  nextNumber: integer("next_number").notNull().default(1),
  businessName: text("business_name").notNull(),
  businessPhone: text("business_phone").notNull(),
  businessEmail: text("business_email"),
  businessAddress: text("business_address"),
  businessTaxId: text("business_tax_id"),
  businessRegNumber: text("business_reg_number"),
  defaultCurrency: text("default_currency").notNull().default("USD"),
  defaultCountry: text("default_country").notNull().default("US"),
  defaultTaxType: text("default_tax_type").default("none"),
  defaultTaxRate: decimal("default_tax_rate", { precision: 5, scale: 2 }).default("0"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const businessProfiles = pgTable("business_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address"),
  website: text("website"),
  taxId: text("tax_id"),
  regNumber: text("reg_number"),
  industry: text("industry"),
  logoUrl: text("logo_url"),
  logoFileName: text("logo_file_name"),
  primaryColor: text("primary_color").default("#3b82f6"),
  secondaryColor: text("secondary_color").default("#f3f4f6"),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const receiptTemplates = pgTable("receipt_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // retail, service, consulting, manufacturing, etc.
  layout: text("layout").notNull(), // compact, detailed, itemized, summary
  showLogo: boolean("show_logo").default(true),
  showBusinessInfo: boolean("show_business_info").default(true),
  showCustomerInfo: boolean("show_customer_info").default(true),
  showItemDetails: boolean("show_item_details").default(true),
  showTaxBreakdown: boolean("show_tax_breakdown").default(true),
  showPaymentMethod: boolean("show_payment_method").default(true),
  showNotes: boolean("show_notes").default(true),
  headerText: text("header_text"),
  footerText: text("footer_text"),
  primaryColor: text("primary_color").default("#3b82f6"),
  secondaryColor: text("secondary_color").default("#f3f4f6"),
  fontFamily: text("font_family").default("inter"),
  fontSize: text("font_size").default("medium"),
  isDefault: boolean("is_default").default(false),
  isCustom: boolean("is_custom").default(false), // true for user-created templates
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type ReceiptItem = {
  id: string;
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
};

export const insertReceiptSchema = createInsertSchema(receipts).omit({
  id: true,
  createdAt: true,
}).extend({
  items: z.array(z.object({
    id: z.string(),
    name: z.string().min(1, "Item name is required"),
    quantity: z.number().min(1, "Quantity must be at least 1"),
    unitPrice: z.number().min(0, "Unit price must be non-negative"),
    total: z.number().min(0, "Total must be non-negative"),
  })).min(1, "At least one item is required"),
  paymentDate: z.union([z.string(), z.date()]).transform((val) => typeof val === 'string' ? new Date(val) : val),
});

export const insertReceiptSettingsSchema = createInsertSchema(receiptSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertBusinessProfileSchema = createInsertSchema(businessProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReceiptTemplateSchema = createInsertSchema(receiptTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Receipt = typeof receipts.$inferSelect;
export type InsertReceipt = z.infer<typeof insertReceiptSchema>;
export type ReceiptSettings = typeof receiptSettings.$inferSelect;
export type InsertReceiptSettings = z.infer<typeof insertReceiptSettingsSchema>;
export type BusinessProfile = typeof businessProfiles.$inferSelect;
export type InsertBusinessProfile = z.infer<typeof insertBusinessProfileSchema>;
export type ReceiptTemplate = typeof receiptTemplates.$inferSelect;
export type InsertReceiptTemplate = z.infer<typeof insertReceiptTemplateSchema>;
